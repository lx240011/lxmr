
library(LXbatmr)


rm(list=ls())

or_dir ="forest data"

mr_method=c("Inverse variance weighted")     #选择展示的方法

# devtools::load_all()

#---------------------------------
fores_plot()
